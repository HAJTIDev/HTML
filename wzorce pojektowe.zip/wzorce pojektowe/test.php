<!DOCTYPE html>
<html lang="en">

<head>
    <title>Test</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="login.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
	<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
</head>

<body>
    <?php
        session_start();
    ?>
	<section class="vh-100 gradient-custom">
        <?php
        $conn = new mysqli('', 'root', '', 'kurs');
        if ($conn->connect_errno)
            die("Connection failed: {$conn->connect_error}");
        ?>
	</section>
</body>

</html>