<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Centrum szkoleniowe dla psów</title>
</head>
<body>
    <div id="container">
        <div id="banner">Centrum szkoleniowe dla psów</div>
        <div id="bottom">
            <table id="tab1">
                <tr>
                    <td><img src="piesek1.png" alt="pies"></td>
                    <td><img src="piesek2.png" alt="pies"></td>
                    <td><img src="piesek3.png" alt="pies"></td>
                    <td><img src="piesek4.png" alt="pies"></td>
                    <td><img src="piesek5.png" alt="pies"></td>
                    <td><img src="piesek6.png" alt="pies"></td>
                </tr>
            </table>
            <p id="p1">Nie ma na świecie przyjaźni, która trwa 
                wiecznie. <br> 
                Jedynym wyjątkiem jest ta, którą obdarza nas pies</p>
                <h3>Konrad Lorenz</h3>
        </div>
        <div id="left"><p id="p2">Kursy w naszym ośrodku prowadzone są w sposób rzetelny. 
            Atmosfera jest przyjazna zwierzętom i ich opiekunom. Zapewniamy indywidualne podejście do 
            każdego psa i jego przewodnika. </p>
            <p id="p2">
            Staramy się, aby każdy z uczestników czuł się komfortowo.
            Szkolenie szczeniaków i dorosłych psów dostosowujemy do temperamentu zwierzęcia oraz jego 
            wieku, ponieważ każdy pies wymaga indywidualnego podejścia i zastosowania odpowiednich 
            technik szkoleniowych.</p>
            <p id="p2">
            Podczas trwania kursu nasi instruktorzy służą swoim wsparciem i 
            doświadczeniem, dzięki czemu szybko nawiążesz kontakt ze swoim psiakiem.</p>
        </div>
        <div id="right">
            <h2>KALENDARZ SZKOLEŃ</h2>
            <table id="tab2">
                <tr>
                    <th>Nazwa szkolenia</th>
                    <th>Data rozpoczęcia</th>
                    <th>Koszt</th>
                </tr>
                <tr>
                    <td class="td2">Psie przedszkole(grupa P1)</td>
                    <td class="td2">03-10-2020</td>
                    <td class="td2">500zł</td>
                </tr>
                <tr>
                    <td class="td2">Posłuszeństwo psa(grupa P2)</td>
                    <td class="td2">10-10-2020</td>
                    <td class="td2">600zł</td>
                </tr>
                <tr>
                    <td class="td2">Posłuszeństwo psa(grupa P3)</td>
                    <td class="td2">07-11-2020</td>
                    <td class="td2">600zł</td>
                </tr>
                <tr>
                    <td class="td2">Psie przedszkole(grupa P4)</td>
                    <td class="td2">14-11-2020</td>
                    <td class="td2">500zł</td>
                </tr>
            </table>

            <h2>Formularz zgłoszeniowy</h2>
            <fieldset id="f1">
                <legend>Dane właściciela</legend>
               <form method="post">
                <label for="name">Imię: </label>
               <input type="text" name="name"id="name"> <br>
               <label for="surname">Nazwwisko: </label>
               <input type="text" name="surname" id="surname"> <br>
               <label for="email">Adres:</label>
               <input type="text" name="email" id="email">
            </fieldset>
            <fieldset>
                <legend>Dane psa</legend>
                <label for="d_name">Imię psa:</label>
                <input type="text" name="d_name" id="d_name"><br>
                <label for="race">Rasa:</label>
                <input type="text" name="race" id="race"><br>
                <label for="date"> Data Urodzenia: </label>
               <input type="date" name="date" id="date"><br>
               <label for="sel"> Rodzaj szkolenia: </label>
                <select name="type" id="sel">
                    <option value="1">Psie przedszkole (P1)</option>
                    <option value="2">Posłuszeństwo psa (P2)</option>
                    <option value="3">Posłuszeństwo psa (P3)</option>
                    <option value="4">Psie przedszkole (P4)</option>
                </select> <br>
                <input type="submit" value="Wyślij zgłoszenie">
                <br>
                </form>
                <?php 
    $conn = new mysqli('','root','','hotel');
    if(isset($_POST['name']) && isset($_POST['surname'])&& isset($_POST['email'])&& isset($_POST['d_name'])&& isset($_POST['race'])&& isset($_POST['date'])){
        $name=$_POST['name'];
        $surname=$_POST['surname'];
        $email=$_POST['email'];
        $d_name=$_POST['d_name'];
        $race=$_POST['race'];
        $date=$_POST['date'];
        $sel=$_POST['type'];

        $sql = "INSERT INTO `wlasciciel`(`Id`, `Imie`, `Nazwisko`, `AdresMail`) VALUES ('','$name','$surname','$email')";
        $conn->query($sql);

        $result=$conn->query("SELECT max(Id) as Id FROM wlasciciel");
        $row=$result->fetch_assoc();
        $id=$row['Id'];

        $sql2 = "INSERT INTO `pies`(`Id`, `Idwlasciciela`, `Imie`, `Rasa`, `DataUrodzenia`) VALUES ('','$id','$d_name','$race','$date')";
        $conn->query($sql2);

        $result=$conn->query("SELECT max(Id) as Id2 FROM pies");
        $row=$result->fetch_assoc();
        $id2=$row['Id2'];

        $sql3 =" INSERT INTO `szkolenie`(`Id`, `IdPsa`, `IdSzkolenia`) VALUES ('','$id2','$sel')";
        $conn->query($sql3);

        echo " dodawanie przeszło pomyślnie";
    }
    $conn->close();
    ?>
        </fieldset>
        </div>
    </div>

</body>
</html>