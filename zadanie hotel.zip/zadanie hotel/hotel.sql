-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 05 Paź 2020, 08:00
-- Wersja serwera: 10.1.37-MariaDB
-- Wersja PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `hotel`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pies`
--

CREATE TABLE `pies` (
  `Id` int(11) NOT NULL,
  `Idwlasciciela` int(11) DEFAULT NULL,
  `Imie` varchar(30) COLLATE utf8_polish_ci DEFAULT NULL,
  `Rasa` varchar(30) COLLATE utf8_polish_ci DEFAULT NULL,
  `DataUrodzenia` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `szkolenie`
--

CREATE TABLE `szkolenie` (
  `Id` int(11) NOT NULL,
  `IdPsa` int(11) DEFAULT NULL,
  `DataSzkolenia` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wlasciciel`
--

CREATE TABLE `wlasciciel` (
  `Id` int(11) NOT NULL,
  `Imie` varchar(30) COLLATE utf8_polish_ci DEFAULT NULL,
  `Nazwisko` varchar(30) COLLATE utf8_polish_ci DEFAULT NULL,
  `AdresMail` varchar(30) COLLATE utf8_polish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `pies`
--
ALTER TABLE `pies`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Idwlasciciela` (`Idwlasciciela`);

--
-- Indeksy dla tabeli `szkolenie`
--
ALTER TABLE `szkolenie`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IdPsa` (`IdPsa`);

--
-- Indeksy dla tabeli `wlasciciel`
--
ALTER TABLE `wlasciciel`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `pies`
--
ALTER TABLE `pies`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `szkolenie`
--
ALTER TABLE `szkolenie`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `wlasciciel`
--
ALTER TABLE `wlasciciel`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `pies`
--
ALTER TABLE `pies`
  ADD CONSTRAINT `pies_ibfk_1` FOREIGN KEY (`Idwlasciciela`) REFERENCES `wlasciciel` (`Id`);

--
-- Ograniczenia dla tabeli `szkolenie`
--
ALTER TABLE `szkolenie`
  ADD CONSTRAINT `szkolenie_ibfk_1` FOREIGN KEY (`IdPsa`) REFERENCES `pies` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
